// 최상위 레이아웃 (로그인 체크만)

import './globals.css'

export const metadata = {
  title: 'neuseon',
  description: '복잡한 거 싫어? 클릭 몇 번이면 돼',
}

export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  )
}