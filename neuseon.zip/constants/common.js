// 공통 상수

// 임시 개발용 사용자 ID
export const TEMP_USER_ID = '00000000-0000-0000-0000-000000000000'

// 매출/지출 구분
export const TRANSACTION_TYPES = {
  INCOME: 'income',
  EXPENSE: 'expense'
}

// 결제 수단
export const PAYMENT_METHODS = {
  CARD: 'card',
  TRANSFER: 'transfer',
  CASH: 'cash'
}

// 결제 수단 한글 표시
export const PAYMENT_METHOD_LABELS = {
  card: '카드',
  transfer: '계좌이체',
  cash: '현금'
}

// 타입 한글 표시
export const TYPE_LABELS = {
  income: '매출',
  expense: '지출'
}