// DB 데이터 → 화면용 데이터 변환 (날짜별 그룹화)
export function transformToTableData(sales) {
  const grouped = {}

  sales.forEach(sale => {
    if (!grouped[sale.date]) {
      grouped[sale.date] = {
        date: sale.date,
        card: 0,
        transfer: 0,
        cash: 0,
        memo: '',
        ids: {
          card: null,
          transfer: null,
          cash: null
        },
        allIds: [] // 모든 id 저장 (삭제용)
      }
    }

    // 금액 설정
    grouped[sale.date][sale.payment_method] = sale.amount
    grouped[sale.date].ids[sale.payment_method] = sale.id
    grouped[sale.date].allIds.push(sale.id) // 모든 id 추가
    
    // 메모 합치기
    if (sale.memo) {
      if (grouped[sale.date].memo) {
        grouped[sale.date].memo += ` / ${sale.memo}`
      } else {
        grouped[sale.date].memo = sale.memo
      }
    }
  })

  return Object.values(grouped).sort((a, b) => b.date.localeCompare(a.date))
}

// 화면용 데이터 → DB 저장용 데이터 변환
export function transformToSalesData(tableRow, type) {
  const sales = []

  if (tableRow.card > 0) {
    sales.push({
      date: tableRow.date,
      amount: tableRow.card,
      payment_method: 'card',
      type: type,
      memo: tableRow.memo
    })
  }

  if (tableRow.transfer > 0) {
    sales.push({
      date: tableRow.date,
      amount: tableRow.transfer,
      payment_method: 'transfer',
      type: type,
      memo: tableRow.memo
    })
  }

  if (tableRow.cash > 0) {
    sales.push({
      date: tableRow.date,
      amount: tableRow.cash,
      payment_method: 'cash',
      type: type,
      memo: tableRow.memo
    })
  }

  return sales
}